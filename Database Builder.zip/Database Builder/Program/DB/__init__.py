from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import declarative_base, Session
from sqlalchemy import create_engine, delete
import socket

db = declarative_base()

# DO NOT MOVE THIS LINE OF CODE EVER * This initialises the models for the DB
# DO NOT MOVE THIS LINE OF CODE EVER * This initialises the models for the DB

url = f"postgresql+psycopg2://postgres:root@theyirosshop.synology.me:2665/yirossandpit"
engine = create_engine(url)
engine.connect()

def create_db():
    db.metadata.drop_all(engine)
    db.metadata.create_all(engine)

