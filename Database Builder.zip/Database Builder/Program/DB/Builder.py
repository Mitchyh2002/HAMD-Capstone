import json


class builder:
    # When Creating A Table import the following ( In Flask App, SQL Alchemy ports aren't required.
    IMPORTS = """from Program.DB import db 
from sqlalchemy import Column 
from sqlalchemy.orm import relationship
from sqlalchemy.types import * \n \n"""

    def __init__(self, Module: dict):

        module_name = Module.get("ModuleName")
        UAC = Module.get("MemberShips")

        self.create_tables(Module.get("Tables"), module_name)

        dependencies = Module.get("Dependencies")

    def create_tables(self, tables, module_name: str):
        for table in tables:
            table_name = f"{module_name.lower()}_{table['TableName'].lower()}"

            with open(f"Models/{table_name}.py", "w+") as model:
                model.write(self.IMPORTS)

                model.write(f"class {table_name}(db):\n")
                model.write(f"\t__tablename__ = '{table_name}'\n")

                # List Comprehension to build out table
                [self.write_column(column, model) for column in table["Columns"]]

            __import__(f'Models.{table_name}')
            pass

    @staticmethod
    def write_column(column, output):

        inputs = {
            "PrimaryKey": "primary_key=",
            "nullable": "nullable=",
            "backref": "backref=",
            "default": "default=",
            "ServerDefault": "server_default=",
            "Unique": "unique=",
            "AutoIncrement": "autoincrement=",
            "ForeignKey": "ForeignKey('"
        }

        rowName = column["rowName"]
        rowType = column["Type"]

        column.pop("rowName")
        column.pop("Type")

        row = f"\t{rowName} = Column("
        row += rowType + ", "


        for (col_name, config) in column.items():
            if col_name == "ForeignKey":
                row += f"{inputs[col_name]}{config}', "
            else:
                row += f"{inputs[col_name]}{config}, "


        row = row[0:-2] + ")\n"
        output.write(row)


if __name__ == "__main__":
    test_json = "../../Test.json"
    with open(test_json, "r") as model:
        content = model.read()
        module_data = json.loads(content)
        builder(module_data)
