from Program.DB import db 
from sqlalchemy import Column 
from sqlalchemy.orm import relationship
from sqlalchemy.types import * 
 
class prototypemodule_quiz(db):
	__tablename__ = 'prototypemodule_quiz'
	id = Column(Integer, primary_key=True, unique=True, autoincrement=True)
	UserID = relationship('Users', 'id')
