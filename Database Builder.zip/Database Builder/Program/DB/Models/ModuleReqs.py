from Program.DB import db
from sqlalchemy import String, Column,Integer

class ModuleRequirment(db):
    __tablename__ = "ModuleRequirments"
    name = Column(String(64))
    WriteAccess = Column(Integer)
    ReadAccess = Column(Integer)
    UseAccess = Column(Integer)