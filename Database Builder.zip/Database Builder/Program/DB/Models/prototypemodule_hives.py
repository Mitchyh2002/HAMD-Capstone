from Program.DB import db
from sqlalchemy import Column
from sqlalchemy.orm import relationship
from sqlalchemy.types import *


class prototypemodule_hives(db):
    __tablename__ = 'prototypemodule_hives'
    id = Column(Integer, primary_key=True, unique=True, autoincrement=True)
    UserID = relationship('Users', 'id')
    HiveName = Column(String(60), nullable=False)
    HiveLocation = relationship('Locations', 'region')
