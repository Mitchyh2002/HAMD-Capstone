from Program.DB import db
from sqlalchemy import Column
from sqlalchemy.orm import relationship
from sqlalchemy.types import *

class Module(db):
    __tablename__ = "Modules"
    name = (String(64))
    WriteAccess = Column(Integer)
    ReadAccess = Column(Integer)
