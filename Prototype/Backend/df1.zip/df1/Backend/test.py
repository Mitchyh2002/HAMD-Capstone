def hello_world():
    return "hi"