from Program.DB.Models.mst.User import PasswordHash, User

def hi():
    return 0
