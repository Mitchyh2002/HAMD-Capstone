from flask import Blueprint, render_template, request, session, redirect, url_for
from Program.ResponseHandler import on_error, on_success
import datetime

blueprint = Blueprint('df1_time', __name__, url_prefix="/df1/time")

@blueprint.route('/')
def Hi():
    return "<h1> Hello World </h1>"

