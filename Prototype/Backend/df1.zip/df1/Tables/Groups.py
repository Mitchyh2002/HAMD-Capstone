from Program import db
from Program.ResponseHandler import on_error

class df1_Group(db.Model):
    __tablename__ = "df1_group"
    groupID = db.Column(db.Integer, primary_key=True, autoincrement=True)
    displayName = db.Column(db.String(200))
    Password = db.Column(db.String(200))
    Test = db.Column(db.String(200), default="Rawr")
    userID = db.Column(db.String(200), db.ForeignKey('user.userID'))

