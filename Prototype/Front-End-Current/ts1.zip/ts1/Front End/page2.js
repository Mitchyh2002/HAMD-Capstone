import React from "react";

export default function Page2(params) {
    return(
        <div>
            <h1>This is the other page</h1>
        </div>
    )
} 