import React from "react";

export default function page1(params) {
    return(
        <div>
            <h1>This is a test</h1>
        </div>
    )
} 