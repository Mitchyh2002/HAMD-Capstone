import React from "react";
import { useState } from "react";

export function df1_Main (params){
    return(<h1> Blahaj Cometh </h1>);
}

export const df1_pages = [{
    path: "Child",
    pageCode: "1",
    Description: "Child",
    userAccessLevel: 1,
    element: '',
    loader: ''
}]