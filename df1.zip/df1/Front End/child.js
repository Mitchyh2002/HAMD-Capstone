import React from "react";

export function child(params) {
    return(
        <div>
            <h1>This is a test</h1>
        </div>
    )
}